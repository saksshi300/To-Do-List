# Project - ToDo List
What is a ToDo List? Simple tool to organise everything

## Give it a Try ?
https://thenishantgiri-todolist.netlify.app/

<img src='https://github.com/thenishantgiri/Project-TodoList-Bootstrap-jQuery/blob/b8d791f5cf04d497ba9af4072e04e9d2e635877a/media/dynamicToDo_Bootstrap_jquery.png' alt='screenshot' width='1280' height='480'>

## Technologies Used
Library : jQuery </br>
Framework : Bootstrap

## Languages Used
HTML </br>
CSS </br>
Javascript

## Working
I have used Bootstrap & jQuery and made a responsive and dynamic ToDo List.

# Connect @
LinkedIn : https://www.linkedin.com/in/thenishantgiri/<br/>
Email : nishantkrgiri@gmail.com<br/>
Twitter : www.twitter.com/thenishantgiri/<br/>

# Personal
Name : Nishant Kumar Giri <br/>
University : University of Delhi, New Delhi


# Gratitude
Thank You, if you like it please leave a Star ;)
          
